<?php include("header.php"); ?>
            <h1>Welcome to MarcoStore!</h1>
<?php include("footer.php"); ?>
